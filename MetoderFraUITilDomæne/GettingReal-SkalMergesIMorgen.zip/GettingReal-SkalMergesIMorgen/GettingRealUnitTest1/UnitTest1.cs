﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GettingRealUnitTest1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        



        }
    }
}
